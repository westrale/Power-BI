# Adding a Slider control to the Bar Chart
A Slider control was added to the sample BarChart for reference.
See [commit](https://github.com/Microsoft/PowerBI-visuals-sampleBarChart/commit/e2e0bc5888d9a3ca305a7a7af5046068645c8b30 ) for what was added at this step.
More detailed documentation to follow.