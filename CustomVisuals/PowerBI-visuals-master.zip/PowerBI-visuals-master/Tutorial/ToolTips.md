# Adding ToolTips to the Bar Chart
Tooltips was added to the sample BarChart for reference.
See [commit](https://github.com/Microsoft/PowerBI-visuals-sampleBarChart/commit/981b021612d7b333adffe9f723ab27783c76fb14) for what was added at this step.
More detailed documentation to follow.
